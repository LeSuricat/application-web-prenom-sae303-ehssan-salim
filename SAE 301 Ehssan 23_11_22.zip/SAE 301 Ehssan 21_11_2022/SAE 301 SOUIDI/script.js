/* 
   pour faire les graphiques, une comparaison de deux prénom par exemple, aller dans le fichier excel (.xlsx)
   puis récupérer les deux lignes qui concerne les deux prénoms (si comparaison entre plus que deux prénom, prendre autant de lignes
   que de prénom que l'on veut comparer) puis les mettres dans un nouveau fichier excel puis exporter en .xlsx . 
   Lié ce fichier ensuite dans vs code 
*/

/*
Idées pour les graphiques :
- Comparaissons d'un ou plusieurs prénoms sur 1 an
- Evolution d'un prénom 
*/
/*
        

        let listePrenoms = tousLesPrenoms.map((item) => item.nombre) // mettre à côté de "data:"
        let labels = tousLesPrenoms.map((item) => item.preusuel) // mettre à côté de ""
*/

let listePrenomsChoisis = ["HUGO", "SAFA", "SASHA", "CHARLES", "JEAN", "ARMAND", "BAPTISTE", "NICOLAS"]
let listPrenomsSelectionnes = tousLesPrenoms.filter((item) => listePrenomsChoisis.includes(item.preusuel))
let nombreNaissances = tousLesPrenoms.map((item) => item.nombre) // mettre à côté de "data:"
let labels = listPrenomsSelectionnes.map((item) => item.preusuel) // mettre à côté de ""

const data = {
    labels: labels,
    datasets: [{
        label: 'Evolution du prénom Jérome durant l année 2005 en Ile de France',
        data: nombreNaissances,
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1,
        backgroundColor: "blue"
    }]
};

const config = {
    type: 'bar',
    data: data,
};


const ctx = document.getElementById('myChart');

new Chart(ctx, config); 