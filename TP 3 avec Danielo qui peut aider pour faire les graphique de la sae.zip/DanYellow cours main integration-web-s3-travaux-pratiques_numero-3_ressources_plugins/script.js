const ctx = document.getElementById('myChart');

  new Chart(ctx, {
    type: 'bar',
    data: {
      /* Définition des champs */
      labels: ['Rouge', 'Bleu', 'Jaune', 'Vert', 'Violet', 'Orange'],
      datasets: [{
        label: ' Répartition des couleurs préféré des étudiants mmi',
        data: [12, 19, 3, 5, 2, 3],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });