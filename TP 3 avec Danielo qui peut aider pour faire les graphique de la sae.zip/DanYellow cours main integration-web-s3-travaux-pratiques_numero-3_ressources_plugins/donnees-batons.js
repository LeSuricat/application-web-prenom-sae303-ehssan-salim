const prenomJerome2005 = [
  { preusuel: 'JEROME', dpt: '60', nombre: 2144 },
  { preusuel: 'JEROME', dpt: '75', nombre: 8017 },
  { preusuel: 'JEROME', dpt: '77', nombre: 2193 },
  { preusuel: 'JEROME', dpt: '78', nombre: 3593 },
  { preusuel: 'JEROME', dpt: '91', nombre: 1907 },
  { preusuel: 'JEROME', dpt: '92', nombre: 3558 },
  { preusuel: 'JEROME', dpt: '93', nombre: 3013 },
  { preusuel: 'JEROME', dpt: '95', nombre: 2099 },
]
