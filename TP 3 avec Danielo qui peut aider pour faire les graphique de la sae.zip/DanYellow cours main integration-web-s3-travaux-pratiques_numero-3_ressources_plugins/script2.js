let data1 = prenomPauline.map((item) => item.nombre) // Donnée, propriété data1
let listeAnnees = prenomPauline.map((item) => item.annais) // Libellé, propriété labels

  
const data = {
  labels: listeAnnees, 
  datasets: [{
    label: 'Evolution du prénom pauline des années 1900 à aujourd hui',
    data: data1,
    fill: false,
    borderColor: 'rgb(75, 192, 192)',
    tension: 0.1
  }]
};

const config = {
    type: 'line',
    data: data,
  };

  
  const ctx = document.getElementById('myChart');

  new Chart(ctx,config);