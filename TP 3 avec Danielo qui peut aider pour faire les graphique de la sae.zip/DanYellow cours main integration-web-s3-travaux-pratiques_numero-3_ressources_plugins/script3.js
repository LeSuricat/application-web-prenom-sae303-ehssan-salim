let data2 = prenomJerome2005.map((item) => item.nombre)
        let listeAnnees = prenomJerome2005.map((item) => item.dpt)
       
const data = {
  labels: listeAnnees,
  datasets: [{
    label: 'Evolution du prénom Jérome durant l année 2005 en Ile de France',
    data: data2,
    fill: false,
    borderColor: 'rgb(75, 192, 192)',
    tension: 0.1,
    backgroundColor : "red"
  }]
};

const config = {
    type: 'bar',
    data: data,
  };

  
  const ctx = document.getElementById('myChart');

  new Chart(ctx,config);